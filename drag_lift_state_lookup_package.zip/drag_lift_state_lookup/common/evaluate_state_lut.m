function value = evaluate_state_lut(lut,Mach,U,H,Re)
%EVALUATE_STATE_LUT Shared runtime interpolation; no extrapolation.
switch lut.mode
    case {'mach','mach-alt','mach-re'}, x = Mach;
    otherwise, x = U;
end
switch lut.mode
    case {'mach-alt','speed-alt'}, y = H;
    case 'mach-re', y = Re;
    otherwise, y = [];
end
if isempty(y)
    value = interp1(lut.x,lut.value,x,'linear',NaN);
else
    value = lut.F((x-lut.offset(1))/lut.span(1), ...
                  (y-lut.offset(2))/lut.span(2));
end
if ~isfinite(value)
    error('StateLUT:OutsideCalibration', ...
        'State outside the supported calibration domain.');
end
end
