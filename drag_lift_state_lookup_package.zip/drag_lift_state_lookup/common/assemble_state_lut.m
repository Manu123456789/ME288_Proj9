function lut = assemble_state_lut(samples,values,mode)
%ASSEMBLE_STATE_LUT Convert state/value samples into a 1-D or 2-D lookup.
% Modes: mach, speed, mach-alt, speed-alt, mach-re.
validModes = {'mach','speed','mach-alt','speed-alt','mach-re'};
if ~ismember(mode,validModes), error('Unsupported lookup mode.'); end

switch mode
    case {'mach','mach-alt','mach-re'}, x = samples.Mach;
    otherwise, x = samples.Speed;
end
switch mode
    case {'mach-alt','speed-alt'}, y = samples.Altitude;
    case 'mach-re', y = samples.Re;
    otherwise, y = [];
end
keep = isfinite(x) & isfinite(values);
if ~isempty(y), keep = keep & isfinite(y); end
x = x(keep); v = values(keep);
if ~isempty(y), y = y(keep); end
if numel(x) < 3, error('Not enough valid calibration samples.'); end

lut.mode = mode;
lut.samples = samples(keep,:);
lut.samples.Value = v;
if isempty(y)
    if min(x) == max(x), error('State input has no variation.'); end
    [~,~,bin] = histcounts(x,linspace(min(x),max(x),61));
    valid = bin > 0;
    x = x(valid); v = v(valid); bin = bin(valid);
    [~,~,group] = unique(bin);
    xb = accumarray(group,x,[],@mean);
    vb = accumarray(group,v,[],@median);
    if numel(xb) < 2, error('Need two distinct 1-D bins.'); end
    lut.x = [min(x);xb;max(x)];
    lut.value = [vb(1);vb;vb(end)];
    [lut.x,ix] = unique(lut.x,'stable');
    lut.value = lut.value(ix);
else
    lut.offset = [min(x),min(y)];
    lut.span = [max(x)-min(x),max(y)-min(y)];
    if any(lut.span <= 0), error('State inputs have no 2-D variation.'); end
    p = [(x-lut.offset(1))/lut.span(1), ...
         (y-lut.offset(2))/lut.span(2)];
    [p,~,g] = unique(p,'rows');
    if size(p,1) < 3 || rank(p-mean(p,1)) < 2
        error('Calibration points do not span a 2-D region.');
    end
    v = accumarray(g,v,[],@median);
    lut.F = scatteredInterpolant(p(:,1),p(:,2),v,'linear','none');
end
end
