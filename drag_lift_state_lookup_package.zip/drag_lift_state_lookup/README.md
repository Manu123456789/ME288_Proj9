# Independent drag and lift state lookups (MATLAB R2021b+)

This package converts optimized **time-dependent** calibration histories into
independent **state-dependent** aerodynamic corrections, with separate builders,
lookups, outputs, and installation commands. The same original `Drag.m`, CFD
`CA/CN` tables, atmosphere, and 5-input `propagate_traj` are reused.

## Folders

- `drag/build_drag_state_lut.m` — converts `outDrag(j).knots/knotScale`.
- `drag/drag_state_scale.m` — runtime drag multiplier.
- `lift/build_lift_state_lut.m` — converts the time-fitted lift correction.
- `lift/lift_state_coefficient.m` — runtime *effective* `CL`.
- `lift/lift_accel_state.m` — uses that `CL` to produce lift acceleration.
- `common/` — shared replay, interpolation, and time-based scale helpers.
- `example_build_luts.m` — complete setup and diagnostic plots.

**User-supplied dependencies:** Your `Drag.m`, `propagate_traj.m` (ODE45 is fine),
`Altitude.m`, `Atmos.m`, working Reynolds calculation and CFD tables, `K_norm`.
The shared `.m` helpers should all be on the MATLAB path; easiest is
`addpath(genpath('drag_lift_state_lookup'))`.

## Build phase (do this BEFORE switching the running forces to state LUTs)

Existing time-calibrated `Drag.m` must still contain:

```matlab
inverseBeta = drag_study_scale(t) * model.K_norm * CD;
```

The ODE dynamics should likewise still use your previously fitted time-based
lift. For prior supplied lift fitter, the lift function uses
`lift_study_coefficient(t)` (independent fitted effective CL). If your lift
fitter instead produced `knotScale`, your time-based lift model must use
`lift_study_scale(t) * aero.CL` for the replay to be consistent.

```matlab
dragLUT = build_drag_state_lut(outDrag,runs,dt,'mach-alt',outLift);
liftLUT = build_lift_state_lut(outLift,outDrag,runs,dt,'mach-alt');
save('aero_state_luts.mat','dragLUT','liftLUT');
```

- `runs(j)` contains `loftDeg`, `time`, `R` (Nx3), and `V` (Nx3).
- `outDrag(j)` corresponds to the same run and contains `knots`, `knotScale`.
- `outLift(j)` corresponds to the same run, with `knots`, **either** `knotCL`
  (effective fitted signed CL) **or** `knotScale` (gain multiplying CFD `aero.CL`).
- No new optimization: the builders rerun the existing propagator with saved
  time-calibrated corrections and fit a state lookup through those samples.
- Provide `outLift` to **both** builders to label scale and lift at the same
  jointly corrected states. To build a drag-only lookup, omit this argument.
- Choose `mode` among `'mach'`, `'speed'`, `'mach-alt'`, `'speed-alt'`, `'mach-re'`.
  The state includes altitude in meters and air-relative speed in m/s.

The converters assume `outDrag`, `outLift`, `runs` align by index. Fit histories
are evaluated on the run's saved timestamps, with actual propagated states used
to label each correction. Replay both corrections during both build passes.

**Important:** `liftOut` from the original supplied lift package uses `knotCL`
**and represents effective CL**, NOT a multiplier on CFD `CL`. The newer table-
multiplier method corresponds to `knotScale`. The package supports either, but
never combines them.

## Switch to the runtime lookup (AFTER building both)

In your existing `Drag.m`, replace ONLY the old time multiplier line with:

```matlab
inverseBeta = drag_state_scale(Mach,U,H,Re) * model.K_norm * CD;
```

**Do not multiply `drag_study_scale` and `drag_state_scale` together.** The
original CFD aerodynamic lookup and `aero.CL` remain unchanged.

In your ODE45 RHS, call once at each RHS evaluation:

```matlab
[aD,aero] = Drag(R,V,t);
aL = lift_accel_state(R,V,aero);  % replaces time-based lift_accel
acc = AccelGrav(R) + aD + aL;
```

Use your existing gravity function name and state shaping. Keep the
5-input signature of `propagate_traj` unchanged.

To run:

```matlab
clear Drag  % refresh any persistent model cached inside Drag
load('aero_state_luts.mat','dragLUT','liftLUT');
drag_state_scale('set',dragLUT);
lift_state_coefficient('set',liftLUT);
[R,V,t] = propagate_traj(R0,V0,t0,tf,dt);
drag_state_scale('reset');
lift_state_coefficient('reset');
```

Lift force uses `aero.qbar`, base-workspace `K_norm`, and a local radial-up
unit vector projected perpendicular to the air-relative velocity. This is a
simplified lift-direction assumption, **not** a reconstructed body attitude.
Match `[0 0 7e-5]` to `Drag.m` Earth rate in both `replay_time_case.m` and
`lift_accel_state.m`. Run `clear lift_accel_state` after changing `K_norm`. This direction must be checked independently of lift
coefficient fitting. Near radial flight the direction is undefined and lift is
set to zero.

## Caveats and diagnostics

- 1-D lookup averages calibration samples into up to 60 state bins (median value), retaining the original state-range endpoints.
- 2-D lookup uses normalized axes and `scatteredInterpolant('linear','none')`.
  A query outside the sample convex hull errors; sparse areas *inside* the
  hull may still be poorly validated.
- If trajectories pass through the same state with different optimized gains,
  a unique state lookup may not exist. Compare predicted and original time-
  calibrated corrections on held-out lofts to detect this problem.
- To avoid circularity, evaluate on lofts **not used** to build the LUTs.
- The lift table-derived `aero.CL` may have incorrect magnitude or force
  orientation. Check its sign and the actual lift-force direction before
  interpreting an optimized lift scale.
- No bounds or extrapolation override is applied; out-of-range state queries
  raise `StateLUT:OutsideCalibration`.
- These functions are independent of MATLAB solver stepping, and compatible
  with `ode45` because they query state continuously (not step index).

## Initial tests

Try `mode='mach'` for each first. Compare with `mode='mach-alt'` and
`mode='mach-re'` where the sample distribution supports a 2-D lookup. A
successful conversion isn't guaranteed: the original optimized correction
may depend on state history, loft, or unmodeled dynamics.

**Not executed in MATLAB.** This is a drop-in scaffold that requires your
existing propagator and force model for integration testing.
