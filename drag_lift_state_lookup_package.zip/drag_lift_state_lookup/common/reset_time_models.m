function reset_time_models()
%RESET_TIME_MODELS Restore nominal force corrections after LUT building.
drag_study_scale('reset');
lift_study_coefficient('reset');
lift_study_scale('reset');
end
