function aL = lift_accel_state(R,V,aero)
%LIFT_ACCEL_STATE State-based lift, radial-up projected across relative wind.
% Uses aero from Drag.m. Does NOT call Drag.m or modify its tables.
aL = zeros(size(V));
if isempty(aero), return; end
R = reshape(R,1,3); V = reshape(V,1,3);
omega = [0 0 7e-5]; % Match Drag.m
Vr = V - cross(omega,R);
U = norm(Vr);
if U == 0, return; end
vhat = Vr/U; rhat = R/norm(R);
eL = rhat-dot(rhat,vhat)*vhat;
if norm(eL) < 1e-8, return; end
eL = eL/norm(eL);
H = Altitude(R);
CL = lift_state_coefficient(aero.Mach,U,H,aero.Re,aero.CL);
persistent K_norm
if isempty(K_norm), K_norm = evalin('base','K_norm'); end
aL = reshape(aero.qbar*K_norm*CL*eL,size(aL));
end
