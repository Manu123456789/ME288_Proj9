function samples = replay_time_case(run,dragFit,liftFit,dt)
%REPLAY_TIME_CASE Replay time-calibrated model and label actual states.
% Drag.m must STILL use drag_study_scale(t), not drag_state_scale.
% The ODE dynamics must use the original time-based lift (if supplied).
t = run.time(:);
if ~isempty(dragFit)
    drag_study_scale('set',dragFit.knots,dragFit.knotScale);
else
    drag_study_scale('reset');
end
lift_study_coefficient('reset');
lift_study_scale('reset');
if ~isempty(liftFit)
    if isfield(liftFit,'knotCL')
        lift_study_coefficient('set',liftFit.knots,liftFit.knotCL);
    elseif isfield(liftFit,'knotScale')
        lift_study_scale('set',liftFit.knots,liftFit.knotScale);
    else
        error('liftFit needs knotCL or knotScale.');
    end
end

[R,V,tp] = propagate_traj(run.R(1,:),run.V(1,:),t(1),t(end),dt);
[tp,idx] = sort(tp(:));
R = interp1(tp,R(idx,:),t,'linear');
V = interp1(tp,V(idx,:),t,'linear');

n = numel(t);
Mach = nan(n,1); Speed = Mach; AltitudeM = Mach; Reynolds = Mach;
omega = [0 0 7e-5]; % Match Drag.m's Earth rate
for k = 1:n
    [~,aero] = Drag(R(k,:),V(k,:),t(k));
    if isempty(aero), continue; end
    Mach(k) = aero.Mach;
    Reynolds(k) = aero.Re;
    AltitudeM(k) = Altitude(R(k,:));
    Speed(k) = norm(V(k,:) - cross(omega,R(k,:)));
end
samples = table(Mach,Speed,AltitudeM,Reynolds, ...
    'VariableNames',{'Mach','Speed','Altitude','Re'});
end
