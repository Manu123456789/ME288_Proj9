function lut = build_lift_state_lut(liftOut,dragOut,runs,dt,mode)
%BUILD_LIFT_STATE_LUT Convert fitted time-based lift to state lookup.
% lut = build_lift_state_lut(liftOut,dragOut,runs,dt,'mach-alt')
% liftOut.knotCL    -> effective signed CL (previous lift package).
% liftOut.knotScale -> multiplier on table-derived aero.CL.
% Run with ORIGINAL time-based drag and lift installed in the propagator.
if nargin < 5 || isempty(mode), mode = 'mach'; end
if numel(liftOut) ~= numel(runs) || numel(dragOut) ~= numel(runs)
    error('liftOut, dragOut, and runs must match.');
end
if isfield(liftOut,'knotCL')
    kind = 'effective-CL'; field = 'knotCL';
elseif isfield(liftOut,'knotScale')
    kind = 'lift-scale'; field = 'knotScale';
else
    error('liftOut needs knotCL or knotScale.');
end
cleanup = onCleanup(@reset_time_models); %#ok<NASGU>
values = [];
for j = 1:numel(runs)
    sj = replay_time_case(runs(j),dragOut(j),liftOut(j),dt);
    t = runs(j).time(:);
    [tk,idx] = sort(liftOut(j).knots(:));
    knotValues = liftOut(j).(field);
    v = interp1(tk,knotValues(idx),t,'linear');
    sj.Loft = repmat(runs(j).loftDeg,numel(t),1);
    if j == 1, samples = sj; else, samples = [samples;sj]; end %#ok<AGROW>
    values = [values;v]; %#ok<AGROW>
end
lut = assemble_state_lut(samples,values,mode);
lut.kind = kind;
end
