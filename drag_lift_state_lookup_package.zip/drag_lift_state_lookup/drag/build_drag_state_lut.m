function lut = build_drag_state_lut(dragOut,runs,dt,mode,liftOut)
%BUILD_DRAG_STATE_LUT Convert time-based drag multipliers to state lookup.
% lut = build_drag_state_lut(dragOut,runs,dt,'mach-alt',liftOut)
% liftOut is optional; include it to replay the SAME states as lift LUT.
% Run while Drag.m still uses drag_study_scale(t).
if nargin < 4 || isempty(mode), mode = 'mach'; end
if nargin < 5, liftOut = []; end
if numel(dragOut) ~= numel(runs), error('dragOut/runs mismatch.'); end
if ~isempty(liftOut) && numel(liftOut) ~= numel(runs)
    error('liftOut/runs mismatch.');
end
cleanup = onCleanup(@reset_time_models); %#ok<NASGU>
values = [];
for j = 1:numel(runs)
    liftFit = [];
    if ~isempty(liftOut), liftFit = liftOut(j); end
    sj = replay_time_case(runs(j),dragOut(j),liftFit,dt);
    t = runs(j).time(:);
    [tk,idx] = sort(dragOut(j).knots(:));
    v = interp1(tk,dragOut(j).knotScale(idx),t,'linear');
    sj.Loft = repmat(runs(j).loftDeg,numel(t),1);
    if j == 1, samples = sj; else, samples = [samples;sj]; end %#ok<AGROW>
    values = [values;v]; %#ok<AGROW>
end
lut = assemble_state_lut(samples,values,mode);
lut.kind = 'drag-scale';
end
