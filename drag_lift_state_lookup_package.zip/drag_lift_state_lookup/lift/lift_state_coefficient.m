function CL = lift_state_coefficient(Mach,U,H,Re,CLtable)
%LIFT_STATE_COEFFICIENT Fitted effective CL for the current flight state.
% lift_state_coefficient('set',lut) installs a state-based lift LUT.
% lift_state_coefficient('reset') disables lift (CL=0).
% 'effective-CL' LUT returns fitted CL directly.
% 'lift-scale' LUT multiplies aero.CL from the original CFD tables.
persistent lut
if ischar(Mach) || isstring(Mach)
    if strcmpi(Mach,'set')
        lut = U;
    elseif strcmpi(Mach,'reset')
        lut = [];
    else
        error('Unknown lift-state command.');
    end
    CL = []; return
end
if isempty(lut), CL = 0; return; end
value = evaluate_state_lut(lut,Mach,U,H,Re);
if strcmp(lut.kind,'effective-CL')
    CL = value;
elseif strcmp(lut.kind,'lift-scale')
    CL = value*CLtable;
else
    error('Unknown lift LUT type.');
end
end
