% 1) BUILD BOTH LOOKUPS BEFORE replacing your time-based force formulas.
% Required workspace variables: runs, outDrag, outLift, dt.
% Existing Drag.m still uses: drag_study_scale(t)
% Existing lift function still uses lift_study_coefficient(t) (effective CL)
% or lift_study_scale(t) * aero.CL (lift multiplier).
%
% Pass outLift into BOTH builders to label the corrections on the same
% replayed, fully time-calibrated states.
dragLUT = build_drag_state_lut(outDrag,runs,dt,'mach-alt',outLift);
liftLUT = build_lift_state_lut(outLift,outDrag,runs,dt,'mach-alt');
save('aero_state_luts.mat','dragLUT','liftLUT');

% Diagnostic plots
figure;
scatter(dragLUT.samples.Mach,dragLUT.samples.Altitude, ...
        12,dragLUT.samples.Value,'filled'); colorbar;
xlabel('Mach'); ylabel('Altitude (m)'); title('Drag scale samples');
figure;
scatter(liftLUT.samples.Mach,liftLUT.samples.Altitude, ...
        12,liftLUT.samples.Value,'filled'); colorbar;
xlabel('Mach'); ylabel('Altitude (m)'); title('Lift samples');

% 2) RUNTIME: After editing Drag.m and your ODE dynamics as in README:
% load('aero_state_luts.mat','dragLUT','liftLUT');
% drag_state_scale('set',dragLUT);
% lift_state_coefficient('set',liftLUT);
% [R,V,time] = propagate_traj(R0,V0,t0,tf,dt);
% drag_state_scale('reset');
% lift_state_coefficient('reset');
