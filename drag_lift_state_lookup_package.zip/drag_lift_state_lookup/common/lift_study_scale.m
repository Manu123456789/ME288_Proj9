function s = lift_study_scale(t,knots,values)
%LIFT_STUDY_SCALE Time-based multiplier on table-derived aero.CL.
% Use only if your time-based lift model was fitted as a multiplier.
persistent tk sv
if ischar(t) || isstring(t)
    switch char(t)
        case 'set'
            [tk,idx] = sort(knots(:));
            sv = values(idx);
        case 'reset'
            tk = []; sv = [];
        otherwise
            error('Unknown lift scale command.');
    end
    s = [];
elseif isempty(sv)
    s = 0; % No lift by default
else
    s = interp1(tk,sv,min(max(t,tk(1)),tk(end)),'linear');
end
end
