function s = drag_state_scale(Mach,U,H,Re)
%DRAG_STATE_SCALE State-based drag multiplier; no extrapolation.
% drag_state_scale('set',lut) installs; 'reset' restores unity gain.
persistent lut
if ischar(Mach) || isstring(Mach)
    if strcmpi(Mach,'set')
        lut = U;
    elseif strcmpi(Mach,'reset')
        lut = [];
    else
        error('Unknown drag-state command.');
    end
    s = []; return
end
if isempty(lut), s = 1; return; end
s = evaluate_state_lut(lut,Mach,U,H,Re);
end
